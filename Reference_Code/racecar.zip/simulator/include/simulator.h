#ifndef Simulator_H_
#define Simulator_H_

#include <iostream>
#include <Eigen/Dense>

#include <ros/ros.h>
#include <ros/console.h>

#include<tf/transform_broadcaster.h>

#include <ros/package.h>
#include <yaml-cpp/yaml.h>

#include <sensor_msgs/Imu.h>
#include <sensor_msgs/Range.h>
#include <nav_msgs/Odometry.h>
#include <Eigen/Eigen>
#include <Eigen/Geometry>
#include <Eigen/Dense>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Path.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include "planner/cmd2car.h"

#include "conversion.h"


using namespace std;
using namespace Eigen;
//! @brief Common variables
const double PI = 3.141592653589793;
const double TAU = 6.283185307179587;

class car
{
public:
	car();
	~car();	

private:
  
};

class landmark {
public:
    std::vector<double> xinner;
    std::vector<double> yinner;
    std::vector<double> xouter;
    std::vector<double> youter;
	std::vector<pair<double, double>> landmark_inner;
	std::vector<pair<double, double>> landmark_outer;
	int size_inner_landmark;
	int size_outer_landmark;
	double observe_dis;

	double not_same_landmark_dis;
	visualization_msgs::Marker landmark_marker_inner_points, landmark_marker_outer_points;

	geometry_msgs::PoseArray landmarks_measurements;
public:
    landmark(){};
    void init();
	void rviz_show_init();
	void rviz_show(ros::Time t, geometry_msgs::Pose car);
	void rviz_show_TEST(ros::Time t, geometry_msgs::Pose car);
	Vector3d transform_coordinate_targetworld2local(geometry_msgs::Pose pose, Vector3d target_world);
	Vector3d transform_coordinate_targetlocal2world(geometry_msgs::Pose car, Vector3d target_local);
};



#endif

