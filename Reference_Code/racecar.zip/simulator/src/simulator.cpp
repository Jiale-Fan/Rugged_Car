#include "simulator.h"
#include <random>

using namespace std;
using namespace Eigen;

double deg2rad(double x) { return x * PI / 180; }
double rad2deg(double x) { return x * 180 / PI; }

const double Lf = 0.33;

double get_dis_square(double x1, double y1, double x2, double y2)
{
  return ((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

VectorXd globalKinematic(VectorXd state, VectorXd actuators, double dt)
{
  VectorXd next_state(state.size());

  //The next_state calculation ...
  //state: x y theta v
  //actuators[0] is steering angle  and actuators[1] is the target speed
  next_state[0] = state[0] + state[3] * cos(state[2])*dt;
  next_state[1] = state[1] + state[3] * sin(state[2])*dt;
  next_state[2] = state[2] + state[3]/Lf *actuators[0]*dt;
  next_state[3] = actuators[1];//state[3] + actuators[1]*dt;
   
  return next_state;
}

planner::cmd2car cmd;
void simulationControlCallback(const planner::cmd2car::ConstPtr &msg)
{
    cmd.steer_angle = msg->steer_angle;
    cmd.velocity = msg->velocity;
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "simulator");
    ros::NodeHandle n;
    ros::Subscriber cmdsub = n.subscribe("/cmd2car", 4, simulationControlCallback);
    ros::Publisher pose_pub = n.advertise<nav_msgs::Odometry>("/ekf/ekf_odom",10);
    ros::Publisher rviz_pub = n.advertise<visualization_msgs::Marker>("rviz_pose", 10);
    ros::Publisher path_pub = n.advertise<nav_msgs::Path>("/path",10);

    ros::Publisher landmark_rviz_pub = n.advertise<visualization_msgs::Marker>("rviz_landmark", 10);
    ros::Publisher landmark_observer_pub = n.advertise<geometry_msgs::PoseArray>("/observed_landmarks", 10);

    tf::TransformBroadcaster car_broadcaster;
    tf::Transform car_transform;

    ros::NodeHandle n_("~");
    bool landmark_show = false;
    n_.getParam("landmark_show", landmark_show); 
    // cout << "landmark_show: " << landmark_show << endl;

    double freq = 100;  //hz
    ros::Rate loop_rate(freq);
    double dt = 1.0/freq;
    double begin_theta = 0.0; //PI/2
    Vector4d state(0, 0, begin_theta, 0);
    Vector2d actuators(0,0);
    cmd.steer_angle = 0;
    cmd.velocity = 0;
    nav_msgs::Path path;
    double speed_bias = 1;

    landmark landmark_sim;
    int cnt_landmark_obs = 0;
    if(landmark_show)
      landmark_sim.init();
    
    //random seed  add some noise
    double translation_noise = 0.1;     
    double rotation_noise = 5.0*PI/180.0;  
    Vector3d noise;
    std::default_random_engine generator;
    std::normal_distribution<double> distribution_translation(0, translation_noise);
    std::normal_distribution<double> distribution_rotation(0, rotation_noise);
    while(ros::ok())
    {
        if(cmd.steer_angle>PI/6)
           cmd.steer_angle = PI/6;
        if(cmd.steer_angle<-PI/6)
           cmd.steer_angle = -PI/6;
        actuators[0] = tan(cmd.steer_angle);
        actuators[1] = cmd.velocity;
        state = globalKinematic(state, actuators, dt);

        visualization_msgs::Marker car;
        car.header.frame_id = "world";
        car.header.stamp = ros::Time::now();
        car.ns = "car";
        car.type = car.CUBE;
        car.action = visualization_msgs::Marker::ADD;
        car.scale.x = 0.55;
        car.scale.y = 0.33;
        car.scale.z = 0.05;
        car.color.a = 1;
        car.color.r = 1;
        car.color.g = 0;
        car.color.b = 0;  

        auto current_time = ros::Time::now();      

        nav_msgs::Odometry odom_fusion;
        odom_fusion.header.stamp = current_time;
        odom_fusion.header.frame_id = "world";
        odom_fusion.pose.pose.position.x = state[0];
        odom_fusion.pose.pose.position.y = state[1];
        odom_fusion.pose.pose.position.z = 0;
        Quaterniond q(yaw2quaternion(state[2]));
        odom_fusion.pose.pose.orientation.w = q.w();
        odom_fusion.pose.pose.orientation.x = q.x();
        odom_fusion.pose.pose.orientation.y = q.y();
        odom_fusion.pose.pose.orientation.z = q.z();

        odom_fusion.twist.twist.linear.x = speed_bias*state[3]*cos(state[2]);
        odom_fusion.twist.twist.linear.y = speed_bias*state[3]*sin(state[2]);
        odom_fusion.twist.twist.linear.z = 0;

        car.pose.position = odom_fusion.pose.pose.position;
        car.pose.orientation = odom_fusion.pose.pose.orientation;

        //tf car
        car_transform.setOrigin(tf::Vector3(car.pose.position.x, car.pose.position.y , car.pose.position.z));
        tf::Quaternion tf_q(car.pose.orientation.x, car.pose.orientation.y, car.pose.orientation.z, car.pose.orientation.w);
        car_transform.setRotation(tf_q);
        car_broadcaster.sendTransform(tf::StampedTransform(car_transform,current_time,"world","car"));//father: world,child: car

        pose_pub.publish(odom_fusion);
        rviz_pub.publish(car);

        cnt_landmark_obs++;//make the pose publish and landmarks observation in a different rate
        if(landmark_show && cnt_landmark_obs > 5)
        {
          cnt_landmark_obs = 0;
          landmark_sim.rviz_show(current_time, odom_fusion.pose.pose);
          landmark_sim.landmark_marker_inner_points.header.stamp = landmark_sim.landmark_marker_outer_points.header.stamp = current_time;

          landmark_rviz_pub.publish(landmark_sim.landmark_marker_inner_points);
          landmark_rviz_pub.publish(landmark_sim.landmark_marker_outer_points);

          // add observation noise
          for(size_t i = 0; i < landmark_sim.landmarks_measurements.poses.size(); i++)
          {
            noise = Vector3d(distribution_translation(generator), distribution_translation(generator), distribution_rotation(generator));  
            // cout << "noise: " << noise << endl;

            landmark_sim.landmarks_measurements.poses.at(i).position.x += noise[0];
            landmark_sim.landmarks_measurements.poses.at(i).position.y += noise[1];

            Quaterniond q_(landmark_sim.landmarks_measurements.poses.at(i).orientation.w, landmark_sim.landmarks_measurements.poses.at(i).orientation.x,landmark_sim.landmarks_measurements.poses.at(i).orientation.y,landmark_sim.landmarks_measurements.poses.at(i).orientation.z);
            double y = quaternion2yaw(q_) + noise[2];
            Quaterniond q(yaw2quaternion(y));
            landmark_sim.landmarks_measurements.poses.at(i).orientation.w = q.w();
            landmark_sim.landmarks_measurements.poses.at(i).orientation.x = q.x();
            landmark_sim.landmarks_measurements.poses.at(i).orientation.y = q.y();
            landmark_sim.landmarks_measurements.poses.at(i).orientation.z = q.z();
          }
          landmark_observer_pub.publish(landmark_sim.landmarks_measurements);
          // cout << "size: " << landmark_sim.landmarks_measurements.poses.size() << endl;
          // for(size_t i = 0; i < landmark_sim.landmarks_measurements.poses.size(); i++)
          // {
          //   cout << "z: " << landmark_sim.landmarks_measurements.poses.at(i).position.z << endl;
          // }
        }
        
        geometry_msgs::PoseStamped this_pose_stamped;
        this_pose_stamped.pose.position.x = odom_fusion.pose.pose.position.x;
        this_pose_stamped.pose.position.y = odom_fusion.pose.pose.position.y;
        this_pose_stamped.pose.position.z = odom_fusion.pose.pose.position.z;
        this_pose_stamped.pose.orientation.x = odom_fusion.pose.pose.orientation.x;
        this_pose_stamped.pose.orientation.y = odom_fusion.pose.pose.orientation.y;
        this_pose_stamped.pose.orientation.z = odom_fusion.pose.pose.orientation.z;
        this_pose_stamped.pose.orientation.w = odom_fusion.pose.pose.orientation.w;
        this_pose_stamped.header.stamp=current_time;
        path.header.frame_id = odom_fusion.header.frame_id;
        path.poses.push_back(this_pose_stamped);
        path_pub.publish(path);

        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}

//landmark
void landmark::init(){
    std::string path = ros::package::getPath("planner")+"/script/parameterize_trajectory/RacecarTrack.yaml";

    YAML::Node node = YAML::LoadFile(path);
    xinner = node["xinner"].as < std::vector < double >> ();
    yinner = node["yinner"].as < std::vector < double >> ();
    xouter = node["xouter"].as < std::vector < double >> ();
    youter = node["youter"].as < std::vector < double >> ();

    int interval_N_in = 4;
    int interval_N_out = 3;
    size_inner_landmark = 0;
    size_outer_landmark = 0;
    for(size_t i=0; i < xinner.size(); i+=interval_N_in)
    {
      landmark_inner.push_back(make_pair(xinner[i], yinner[i]));
      size_inner_landmark++;
    }
    // cout << "size_inner_landmark: " << size_inner_landmark << endl; 
    for(size_t i=0; i < xouter.size(); i+=interval_N_out)
    {
      landmark_outer.push_back(make_pair(xouter[i], youter[i]));
      size_outer_landmark++;
    }
    // cout << "size_outer_landmark: " << size_outer_landmark << endl; 

    observe_dis = 2;  //observation distance of landmark
    not_same_landmark_dis = 0.3; // not same landmark distance, less than this ,will be seen as one landmark.

    rviz_show_init();
}

void landmark::rviz_show_init()
{
  landmark_marker_inner_points.header.frame_id = landmark_marker_outer_points.header.frame_id = "world";
  landmark_marker_inner_points.ns = landmark_marker_outer_points.ns = "landmark";
  landmark_marker_inner_points.action = landmark_marker_outer_points.action = visualization_msgs::Marker::ADD;
  landmark_marker_inner_points.pose.orientation.w = landmark_marker_outer_points.pose.orientation.w = 1.0;
  landmark_marker_inner_points.type = landmark_marker_outer_points.type = visualization_msgs::Marker::POINTS;

  landmark_marker_inner_points.id = 0;
  landmark_marker_inner_points.scale.x = 0.1;
  landmark_marker_inner_points.scale.y = 0.1;
  landmark_marker_inner_points.color.a = 1;
  landmark_marker_inner_points.color.g = 1;

  landmark_marker_outer_points.id = 1;
  landmark_marker_outer_points.scale.x = 0.1;
  landmark_marker_outer_points.scale.y = 0.1;
  landmark_marker_outer_points.color.a = 1;
  landmark_marker_outer_points.color.b = 1;
}

void landmark::rviz_show_TEST(ros::Time t, geometry_msgs::Pose car)
{
  geometry_msgs::Point pin,pout;

  for(int i=0; i < size_inner_landmark; i++)
  {
    pin.x = landmark_inner[i].first;
    pin.y = landmark_inner[i].second;
    pin.z = 0;

    landmark_marker_inner_points.points.push_back(pin);
  }
  cout << "landmark_marker_inner_points.points: " << landmark_marker_inner_points.points.size() << endl;

  for(int i=0; i < size_outer_landmark; i++)
  {
    pout.x = landmark_outer[i].first;
    pout.y = landmark_outer[i].second;
    pout.z = 0;
    
    landmark_marker_outer_points.points.push_back(pout);
  }
  cout << "andmark_marker_outer_points.points.size: " << landmark_marker_outer_points.points.size() << endl;
}

void landmark::rviz_show(ros::Time t, geometry_msgs::Pose car)
{
  geometry_msgs::Point pin,pout;
  geometry_msgs::Pose landmarks_pose;
  landmarks_pose.orientation.w =1;
  landmarks_measurements.poses.clear();
  landmarks_measurements.header.frame_id = "car";
  landmarks_measurements.header.stamp = t;

  //when the landmark is near forword the car, it can be observed.
  for(int i=0; i < size_inner_landmark; i++)
  {
    
    if(get_dis_square(car.position.x, car.position.y, landmark_inner[i].first, landmark_inner[i].second) < observe_dis*observe_dis)
    {
      // transform landmark into car frame
      Vector3d landmark_target(landmark_inner[i].first, landmark_inner[i].second, 0);
      Vector3d landmark_target_c = transform_coordinate_targetworld2local(car, landmark_target);
      // Vector3d landmark_target_w = transform_coordinate_targetlocal2world(car, landmark_target_c);

      if(landmark_target_c(0) > 0) //only observe the landmark forward the car TODO can add sight of view angle to simulate the camera.
      {
        //observation
        landmarks_pose.position.x = landmark_target_c(0);
        landmarks_pose.position.y = landmark_target_c(1);
        // landmarks_pose.position.z = -1;  // -1 is inner landmarks. 1 is outer landmarks.
        // landmarks_measurements.poses.push_back(landmarks_pose);

        if(landmark_marker_inner_points.points.size()==0)
        {
          pin.x = landmark_inner[i].first;
          pin.y = landmark_inner[i].second;
          pin.z = 0;

          landmark_marker_inner_points.points.push_back(pin);

          //TODO for landmarks id Max_landmarks should be less than 1000
          landmarks_pose.position.z = (double)(-1000);  // <0 is inner landmarks. >0 is outer landmarks.  -1000 is inner 0
          // cout << "l_z1: " << landmarks_pose.position.z << endl;
          landmarks_measurements.poses.push_back(landmarks_pose);
        }
        else
        {
          bool landmark_exit = false;
          int N_landmark_inner = landmark_marker_inner_points.points.size();
          // cout << "N_landmark_inner: " << N_landmark_inner << endl;
          for(int j=0; j < N_landmark_inner; j++)
          {
            if(get_dis_square(landmark_marker_inner_points.points[j].x, landmark_marker_inner_points.points[j].y, landmark_inner[i].first, landmark_inner[i].second) < not_same_landmark_dis*not_same_landmark_dis)
            {
              landmark_exit = true;

              //TODO for landmarks id Max_landmarks should be less than 1000
              if(j == 0)
                landmarks_pose.position.z = (double)(-1000);  // <0 is inner landmarks. >=0 is outer landmarks.   -1000 is inner 0 
              else
                landmarks_pose.position.z = (double)(-j);  // <0 is inner landmarks. >=0 is outer landmarks.   -1000 is inner 0
              // cout << "l_z2: " << landmarks_pose.position.z << endl;
              landmarks_measurements.poses.push_back(landmarks_pose);

              break;
            }
          }
          if(!landmark_exit)
          {
            pin.x = landmark_inner[i].first;
            pin.y = landmark_inner[i].second;
            pin.z = 0;

            landmark_marker_inner_points.points.push_back(pin);
            cout << "landmark_marker_inner_points.points: " << landmark_marker_inner_points.points.size() << endl;

            //TODO for landmarks id Max_landmarks should be less than 1000
            landmarks_pose.position.z = -1.0 * (double)(landmark_marker_inner_points.points.size()-1);  // <0 is inner landmarks. >0 is outer landmarks.  -1000 is inner 0 //不能 -1 * (size or unsigned ) 会出现很大的数！！！！！！
            // cout << "l_z3: " << landmarks_pose.position.z << endl; 
            landmarks_measurements.poses.push_back(landmarks_pose);
          }
        }
      }
    }
  }

  for(int i=0; i < size_outer_landmark; i++)
  {
    if(get_dis_square(car.position.x, car.position.y, landmark_outer[i].first, landmark_outer[i].second) < observe_dis*observe_dis)
    {
      // transform landmark into car frame
      Vector3d landmark_target(landmark_outer[i].first, landmark_outer[i].second, 0);
      Vector3d landmark_target_c = transform_coordinate_targetworld2local(car, landmark_target);
      // Vector3d landmark_target_w = transform_coordinate_targetlocal2world(car, landmark_target_c);

      if(landmark_target_c(0) > 0) //only observe the landmark forward the car TODO can add sight of view angle to simulate the camera.
      {
        //observation
        landmarks_pose.position.x = landmark_target_c(0);
        landmarks_pose.position.y = landmark_target_c(1);
        // landmarks_pose.position.z = 1;  // -1 is inner landmarks. 1 is outer landmarks.
        // landmarks_measurements.poses.push_back(landmarks_pose);

        if(landmark_marker_outer_points.points.size()==0)
        {
          pout.x = landmark_outer[i].first;
          pout.y = landmark_outer[i].second;
          pout.z = 0;
          
          landmark_marker_outer_points.points.push_back(pout);

          //TODO for landmarks id 
          landmarks_pose.position.z = (double)(landmark_marker_outer_points.points.size()-1);  // <0 is inner landmarks. >0 is outer landmarks.
          landmarks_measurements.poses.push_back(landmarks_pose);
        }
        else
        {
          bool landmark_exit = false;
          int N_landmark_outer = landmark_marker_outer_points.points.size();
          // cout << "N_landmark_outer: " << N_landmark_outer << endl;
          for(int j=0; j < N_landmark_outer; j++)
          {
            if(get_dis_square(landmark_marker_outer_points.points[j].x, landmark_marker_outer_points.points[j].y, landmark_outer[i].first, landmark_outer[i].second) < not_same_landmark_dis*not_same_landmark_dis)
            {
              landmark_exit = true;

              //TODO for landmarks id 
              landmarks_pose.position.z = (double)(j);  // <0 is inner landmarks. >0 is outer landmarks.
              landmarks_measurements.poses.push_back(landmarks_pose);

              break;
            }
          }
          if(!landmark_exit)
          {
            pout.x = landmark_outer[i].first;
            pout.y = landmark_outer[i].second;
            pout.z = 0;
            
            landmark_marker_outer_points.points.push_back(pout);
            cout << "landmark_marker_outer_points.points: " << landmark_marker_outer_points.points.size() << endl;

            //TODO for landmarks id 
            landmarks_pose.position.z = (double)(landmark_marker_outer_points.points.size()-1);  // <0 is inner landmarks. >0 is outer landmarks.
            landmarks_measurements.poses.push_back(landmarks_pose);
          }
        }
      }
    }
  }


}

Vector3d landmark::transform_coordinate_targetworld2local(geometry_msgs::Pose car, Vector3d target_world)
{
  Quaterniond q(car.orientation.w, car.orientation.x, car.orientation.y, car.orientation.z);
  Matrix3d Rc_w = q.toRotationMatrix();
  Matrix3d Rw_c = Rc_w.inverse();
  Vector3d Tc_w(car.position.x, car.position.y, 0);
  Vector3d Tw_c = -Rw_c*Tc_w;
  Vector3d Ptarget_w(target_world(0), target_world(1), 0);
  Vector3d Ptarget_c = Rw_c*Ptarget_w + Tw_c;

  return Ptarget_c;
}

Vector3d landmark::transform_coordinate_targetlocal2world(geometry_msgs::Pose car, Vector3d target_local)
{
  Quaterniond q(car.orientation.w, car.orientation.x, car.orientation.y, car.orientation.z);
  Matrix3d Rc_w = q.toRotationMatrix();
  Vector3d Tc_w(car.position.x, car.position.y, 0);
  Vector3d Ptarget_c(target_local(0), target_local(1), 0);
  Vector3d Ptarget_w = Rc_w*Ptarget_c + Tc_w;

  return Ptarget_w;
}