#ifndef PROJECT_MAP_H
#define PROJECT_MAP_H

#include <Eigen/Core>
#include <cmath>
#include <iostream>
#include <yaml-cpp/yaml.h>
#include "my_spline.h"
#include <ros/ros.h>
#include <ros/package.h>


// class Map
class mymap {
public:
    std::vector<double> xcenter;
    std::vector<double> ycenter;
    std::vector<double> xinner;
    std::vector<double> yinner;
    std::vector<double> xouter;
    std::vector<double> youter;
public:
    struct Traj {
        double trackWidth = 0;
        std::vector<double> theta;

        std::vector<double> length;
        double PathLength;
        double dl;

        tk::spline xcenter;
        tk::spline ycenter;
    };
    Traj traj;

    mymap(){};
    void init();

    void splineMap();

    double calculateTheta(double currentX, double currentY);
    double calculateTheta2(double currentX, double currentY);

};


#endif //PROJECT_MAP_H
