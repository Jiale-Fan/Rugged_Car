#ifndef Trajectory_Generator_H
#define Trajectory_Generator_H

#include <iostream>
#include <ros/ros.h>
#include <ros/console.h>
#include <Eigen/Eigen>
#include <Eigen/Geometry>
#include <Eigen/Dense>
#include <cstdlib>

#include <nav_msgs/Odometry.h>

#include "conversion.h"

#include "planner/nextpose.h"
#include "planner/goal.h"
#include "planner/status.h"

using namespace std; 
using namespace Eigen;
//! @brief Common variables
const double PI = 3.141592653589793;
const double TAU = 6.283185307179587;


vector<Vector4d> Trajectory;
ros::Publisher pose_target_pub;
ros::Timer timer;

ros::Timer timer_show;
ros::Publisher pose_target_show_pub;
ros::Publisher monitor_pub;
ros::Publisher path_pub;
nav_msgs::Odometry pose_target_show;

double controlrate = 50;

void system_monitor_pub(ros::Time stamp, double x, double y, double z);



#endif

