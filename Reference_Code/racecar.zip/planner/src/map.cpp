#include "map.h"

void mymap::init(){
    std::string path = ros::package::getPath("planner")+"/script/parameterize_trajectory/RacecarTrack.yaml";
    // std::cout << path << std::endl;

    YAML::Node node = YAML::LoadFile(path);
    xcenter = node["xcenter"].as < std::vector < double >> ();
    ycenter = node["ycenter"].as < std::vector < double >> ();
    xinner = node["xinner"].as < std::vector < double >> ();
    yinner = node["yinner"].as < std::vector < double >> ();
    xouter = node["xouter"].as < std::vector < double >> ();
    youter = node["youter"].as < std::vector < double >> ();

    xcenter.push_back(xcenter[0]);// for close loop  !!!!!!!!
    ycenter.push_back(ycenter[0]);//TODO: think about the size of trajsize

    splineMap();
}

void mymap::splineMap() {  //Discretization into the num of waypoints
    std::vector<double> t;
    for (unsigned int i = 0; i < xcenter.size(); ++i) {
        t.push_back(i);
    }
    // normalization
    traj.xcenter.set_points(t, xcenter);
    traj.ycenter.set_points(t, ycenter);
    for (unsigned int j = 0; j < xcenter.size(); ++j) {
        if (j == 0) traj.theta.push_back(0);
        else {
            double rightdiff = sqrt(pow(traj.xcenter(j, 1), 2) + pow(traj.ycenter(j, 1), 2));
            double leftdiff = sqrt(pow(traj.xcenter(j - 1, 1), 2) + pow(traj.ycenter(j - 1, 1), 2));
            traj.theta.push_back(traj.theta[j - 1] + (leftdiff + rightdiff) / 2);
        }
    }
    
    // spline with theta(length of track centerline)
    traj.xcenter.set_points(traj.theta, xcenter);  // use the length as the parameter
    traj.ycenter.set_points(traj.theta, ycenter);

    std::vector<double> xcenter_, ycenter_;
    //for the first point is the same as the last point
    size_t trajSize = traj.theta.size(); //use the same "point number" of theta
    traj.PathLength = traj.theta[trajSize-1];  //TODO: think about the size of trajsize
    traj.dl = traj.PathLength/(trajSize-1);   //for the first point is the same as the last point
    for(size_t i = 0; i < trajSize; ++i)
    {
        double l = traj.dl*i;
        traj.length.push_back(l);  // 0 dl 2dl ...  
        xcenter_.push_back(traj.xcenter(l));
        ycenter_.push_back(traj.ycenter(l));
    }
    traj.xcenter.set_points(traj.length, xcenter_);  // use the length as the parameter
    traj.ycenter.set_points(traj.length, ycenter_);
    //use sketch map to ensure the size
}

double mymap::calculateTheta(double currentX, double currentY) {
    // just tranverse each item in thetalist to find the nearest one
    double distanceX2, distanceY2, distance, nearestDistance;
    size_t nearestId = 0, realPreviousId = 0;
    size_t trajSize = traj.length.size();

    for (unsigned int i = 0; i < trajSize; ++i) {
        distanceX2 = pow(traj.xcenter(traj.length[i]) - currentX, 2);
        distanceY2 = pow(traj.ycenter(traj.length[i]) - currentY, 2);
        distance = sqrt(distanceX2 + distanceY2);
        if (i == 0) {
            nearestDistance = distance;
        } else if (distance < nearestDistance) {
            nearestDistance = distance;
            nearestId = i;
        }
    }

    return traj.length[nearestId];
    // /**
    //  * vector1: nearest ==> current
    //  * vector2: nearest ==> previous
    //  * if vector1 * vector2 > 0:
    //  *    real previous <- nearest
    //  * else:
    //  *    real previous <- previous
    //  * **/
    // unsigned int previousId = (nearestId + trajSize - 1) % trajSize;
    // double deltaTheta = 0;
    // double nearestX = traj.xcenter(traj.length[nearestId]);
    // double nearestY = traj.ycenter(traj.length[nearestId]);

    // double previousX = traj.xcenter(traj.length[previousId]);
    // double previousY = traj.ycenter(traj.length[previousId]);
    // double this_or_previous = (currentX - nearestX) * (previousX - nearestX) +
    //                             (currentY - nearestY) * (previousY - nearestY);
    // realPreviousId = this_or_previous > 0 ? previousId : nearestId;
    // //todo: I cannot understand it... perhaps this is what we call magic?
    // return deltaTheta + traj.length[realPreviousId];
}
double mymap::calculateTheta2(double currentX, double currentY) {
    // just tranverse each item in thetalist to find the nearest one
    double distanceX2, distanceY2, distance, nearestDistance;
    unsigned int nearestId = 0, realPreviousId = 0;
    unsigned int trajSize = traj.theta.size();
    //!!!!!!!!!the length interval is not the same!!!!!!!!!!!!!!
    for (unsigned int i = 0; i < trajSize; ++i) {
        distanceX2 = pow(traj.xcenter(traj.theta[i]) - currentX, 2);
        distanceY2 = pow(traj.ycenter(traj.theta[i]) - currentY, 2);
        distance = sqrt(distanceX2 + distanceY2);
        if (i == 0) {
            nearestDistance = distance;
        } else if (distance < nearestDistance) {
            nearestDistance = distance;
            nearestId = i;
        }
    }
    /**
     * vector1: nearest ==> current
     * vector2: nearest ==> previous
     * if vector1 * vector2 > 0:
     *    real previous <- nearest
     * else:
     *    real previous <- previous
     * **/
    unsigned int previousId = (nearestId + trajSize - 1) % trajSize;
    double deltaTheta = 0;
    double nearestX = traj.xcenter(traj.theta[nearestId]);
    double nearestY = traj.ycenter(traj.theta[nearestId]);

    double previousX = traj.xcenter(traj.theta[previousId]);
    double previousY = traj.ycenter(traj.theta[previousId]);
    double this_or_previous = (currentX - nearestX) * (previousX - nearestX) +
                                (currentY - nearestY) * (previousY - nearestY);
    realPreviousId = this_or_previous > 0 ? previousId : nearestId;
    //todo: I cannot understand it... perhaps this is what we call magic?
    return deltaTheta + traj.theta[realPreviousId];
}


