#include "trajectory_generator.h"
#include "map.h"
//simulator
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>

using namespace std;
using namespace Eigen;

ros::Publisher sim_ref_pub;
nav_msgs::Path Pathref;
ros::Publisher sim_border_inner_pub;
ros::Publisher sim_border_outer_pub;
nav_msgs::Path Pathborder_inner;
nav_msgs::Path Pathborder_outer;

double limit_nPi2pPi(double theta) //as for theta range in pi/2~5pi/2
{
    if(theta > PI)
    {
        theta = theta - 2*PI;
    }
    if(theta < -PI)
    {
        theta = theta + 2*PI;
    }
    return theta;
}

bool theta_close_to_last_theta(double theta_last, double theta)
{
    if(abs(theta_last - theta) < PI/2)
        return true;
    if(abs(theta_last - theta) > PI)
    {
        if(abs(abs(theta_last - theta)-2*PI) < PI/2)
            return true;
    }
    return false;
}

double dir_generate(double dy, double dx)
{
    static double theta_last = 0; //TODO:must begin in theta = 0
    double theta_ = 0;

    theta_ = atan2(dy, dx);
    if(!theta_close_to_last_theta(theta_last, theta_))  //choose the theta with the closer direction
    {
        //TODO:Once some wrongs occur, it will be crash; use position diff to get the direction
        // cout << "======= "<< theta_last << "  " << theta_ <<"==========" << endl;
        theta_ = theta_ + PI;
    }
    
    theta_last = limit_nPi2pPi(theta_);
    return theta_last;
}

mymap routeCenter;
double dl; //dl for the interval of the vector Trajectory
double forward_length;  //trace the pose in forward_length
int forward_cnt; //the additional cnt of vector Trajectory around forward_length
double forward_time = 0.01;
double set_vel = 1;
double velocity_now;
void trajectory_generator()
{
    routeCenter.init();
    double v_temp = set_vel; //2.5 can not follow the trajatory   may be too fast
    
    double length, x, y, theta, v, dy, dx;
    dl = routeCenter.traj.dl;
    cout << "dl: " << dl << endl;
    cout << "Path length: " << routeCenter.traj.length.size()*dl << endl;
    for(size_t i = 0; i < routeCenter.traj.length.size(); i++)
    {
        length = routeCenter.traj.length[i];
        x = routeCenter.traj.xcenter(length);
        y = routeCenter.traj.ycenter(length);
        dy = routeCenter.traj.ycenter(length,1);
        dx = routeCenter.traj.xcenter(length,1);
        theta = dir_generate(dy, dx);//limit theta
        v = v_temp;
        Vector4d traj_point(x,y,theta,v);
        Trajectory.push_back(traj_point);
    }
}


size_t cnt;
//ensure get the firstpoint
bool first_point_received = false;
void movement_callback2(const planner::status::ConstPtr &msg)
{
    // ROS_INFO("Movement callback"); 
    planner::goal nextpoint;

    if(msg->arrive == 3) //first_point_receivedfirst_point_received
    {
        first_point_received = true;
        timer.start();
        timer_show.start();
    }

    if(msg->arrive == 2) //first point not send successfully
    {
        double velocity_begin = Trajectory[0](3);
        forward_length = velocity_begin*forward_time;
        planner::goal nextpoint;
        nextpoint.x = routeCenter.traj.xcenter(forward_length);
        nextpoint.y = routeCenter.traj.ycenter(forward_length);
        nextpoint.theta = dir_generate(routeCenter.traj.ycenter(forward_length,1), routeCenter.traj.xcenter(forward_length,1));//limit theta;
        nextpoint.velocity = velocity_begin;
        pose_target_pub.publish(nextpoint);
        ROS_INFO("Sent first point!");
    }
    //simulator
    sim_ref_pub.publish(Pathref);
}

Vector4d pose2d_now;
nav_msgs::Odometry position_now;
void odom_callback(const nav_msgs::Odometry::ConstPtr &msg)
{
    Quaterniond q(msg->pose.pose.orientation.w, msg->pose.pose.orientation.x, msg->pose.pose.orientation.y, msg->pose.pose.orientation.z);

    pose2d_now(0) = msg->pose.pose.position.x;
    pose2d_now(1) = msg->pose.pose.position.y;
    pose2d_now(2) = quaternion2yaw(q);  //-pi -- pi
    // cout << "================pose2d: " << pose2d_now(2) << endl;
    pose2d_now(3) = sqrt(msg->twist.twist.linear.x*msg->twist.twist.linear.x
                        +msg->twist.twist.linear.y*msg->twist.twist.linear.y);
                        // +msg->twist.twist.linear.z*msg->twist.twist.linear.z);
    //cout << "odom" << endl;
    system_monitor_pub(msg->header.stamp,pose2d_now(3),0,0);

    //keep the path
    position_now.header = msg->header;
    position_now.pose = msg->pose;
    position_now.twist = msg->twist;
}

size_t find_nearest_point_in_traj_front(Vector4d Posenow)
{//find the nearest point in a period
    static size_t n_last = 0;
    size_t n = 0;
    double min = pow((Posenow(0)-Trajectory[0](0)),2) + pow((Posenow(1)-Trajectory[0](1)),2);
    for(size_t i=1; i < Trajectory.size(); i++)
    {
        double dis_temp = pow((Posenow(0)-Trajectory[i](0)),2) + pow((Posenow(1)-Trajectory[i](1)),2);
        if(min > dis_temp)
        {
            min = dis_temp;
            n = i;
        }
    }
    Quaterniond q(yaw2quaternion(Posenow(2)));
    Matrix3d Rc_w = q.toRotationMatrix();
    Matrix3d Rw_c = Rc_w.inverse();
    Vector3d Tc_w(Posenow(0), Posenow(1), 0);
    Vector3d Tw_c = -Rw_c*Tc_w;
    Vector3d Ptarget_w(Trajectory[n](0), Trajectory[n](1), 0);
    Vector3d Ptarget_c = Rw_c*Ptarget_w + Tw_c;
    if(Ptarget_c(0) < 0) //find_nearest_point_in_traj    front
    {
        n += 1;
    }
    n_last = n;
    return n;
}

//parameterize road
nav_msgs::Path path;
void timerCallback(const ros::TimerEvent& event)  //run per delta_t time
{
    static ros::Time t = ros::Time::now();
    double ddt = (ros::Time::now() - t).toSec();
    t = ros::Time::now();
    //cout << "dt: " << ddt << endl;

    double cnt = find_nearest_point_in_traj_front(pose2d_now);

    velocity_now = pose2d_now(3);
    if(velocity_now < 1)  
    {   
        // when the speed is low, give a fixed forward point
        //ensure the target is front when beginning
        forward_length = 0.3;
    } 
    else
    {
        forward_length = velocity_now * forward_time;  //trace the pose in forward_length
    }
    forward_cnt = (int)(forward_length/dl);

    cnt = cnt + forward_cnt; //target point for velocity

    if(first_point_received)
    {
        planner::goal nextpoint;
        if(cnt >= Trajectory.size())
        {
            cnt = cnt-(Trajectory.size());
            double nearest_length = routeCenter.traj.length[cnt];
            double nextPose_length = nearest_length+forward_length;
            ROS_INFO("Finish a round!");
            nextpoint.x = routeCenter.traj.xcenter(nextPose_length);
            nextpoint.y = routeCenter.traj.ycenter(nextPose_length);
            nextpoint.theta = dir_generate(routeCenter.traj.ycenter(nextPose_length,1), routeCenter.traj.xcenter(nextPose_length,1));//limit theta;
            nextpoint.velocity = Trajectory[cnt](3);
            pose_target_pub.publish(nextpoint);
            //ROS_INFO("Sent a point!");
        }
        else
        {
            //sent next point
            double nearest_length = routeCenter.traj.length[cnt];
            double nextPose_length = nearest_length+forward_length;
            nextpoint.x = routeCenter.traj.xcenter(nextPose_length);
            nextpoint.y = routeCenter.traj.ycenter(nextPose_length);
            nextpoint.theta = dir_generate(routeCenter.traj.ycenter(nextPose_length,1), routeCenter.traj.xcenter(nextPose_length,1));//limit theta;
            nextpoint.velocity = Trajectory[cnt](3);
            pose_target_pub.publish(nextpoint);
            //ROS_INFO("Sent a point!");
        }

        //show the target pose
        pose_target_show.header.stamp = t;
        pose_target_show.header.frame_id = "world";
        pose_target_show.pose.pose.position.x = nextpoint.x;
        pose_target_show.pose.pose.position.y = nextpoint.y;
        pose_target_show.pose.pose.position.z = 0;
        Quaterniond q(yaw2quaternion(nextpoint.theta));
        pose_target_show.pose.pose.orientation.w = q.w();
        pose_target_show.pose.pose.orientation.x = q.x();
        pose_target_show.pose.pose.orientation.y = q.y();
        pose_target_show.pose.pose.orientation.z = q.z();
        pose_target_show_pub.publish(pose_target_show);

        geometry_msgs::PoseStamped this_pose_stamped;
        this_pose_stamped.pose.position.x = position_now.pose.pose.position.x;
        this_pose_stamped.pose.position.y = position_now.pose.pose.position.y;
        this_pose_stamped.pose.position.z = position_now.pose.pose.position.z;
        this_pose_stamped.pose.orientation.x = position_now.pose.pose.orientation.x;
        this_pose_stamped.pose.orientation.y = position_now.pose.pose.orientation.y;
        this_pose_stamped.pose.orientation.z = position_now.pose.pose.orientation.z;
        this_pose_stamped.pose.orientation.w = position_now.pose.pose.orientation.w;
        this_pose_stamped.header.stamp=position_now.header.stamp;
        path.header.frame_id = position_now.header.frame_id;
        path.poses.push_back(this_pose_stamped);
        path_pub.publish(path);
    }
}

void border_show_init()
{
    Pathborder_inner.header.frame_id = "world";
    Pathborder_outer.header.frame_id = "world";
    geometry_msgs::PoseStamped tmpPose_inner, tmpPose_outer;
    for(int i=0; i < routeCenter.xinner.size(); i++)
    {
        tmpPose_inner.pose.position.x = routeCenter.xinner[i];
        tmpPose_inner.pose.position.y = routeCenter.yinner[i];
        tmpPose_inner.pose.position.z = 0;
        Quaterniond q(yaw2quaternion(0));
        tmpPose_inner.pose.orientation.w = q.w();
        tmpPose_inner.pose.orientation.x = q.x();
        tmpPose_inner.pose.orientation.y = q.y();
        tmpPose_inner.pose.orientation.z = q.z();
        Pathborder_inner.poses.push_back(tmpPose_inner);
    }
    for(int i=0; i < routeCenter.xouter.size(); i++)
    {
        tmpPose_outer.pose.position.x = routeCenter.xouter[i];
        tmpPose_outer.pose.position.y = routeCenter.youter[i];
        tmpPose_outer.pose.position.z = 0;
        Quaterniond q(yaw2quaternion(0));
        tmpPose_outer.pose.orientation.w = q.w();
        tmpPose_outer.pose.orientation.x = q.x();
        tmpPose_outer.pose.orientation.y = q.y();
        tmpPose_outer.pose.orientation.z = q.z();
        Pathborder_outer.poses.push_back(tmpPose_outer);
    }
}

void timercallback_show(const ros::TimerEvent& event)
{
    //simulator
    sim_ref_pub.publish(Pathref);
    sim_border_inner_pub.publish(Pathborder_inner);
    sim_border_outer_pub.publish(Pathborder_outer);
}

void trajectory_generator_init(ros::NodeHandle &n)
{
    n.getParam("controlrate", controlrate); 
    n.getParam("set_vel", set_vel); 
    n.getParam("set_forward_time", forward_time); 
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "trajectory_generator");
    ros::NodeHandle n("~");
    trajectory_generator_init(n);
    ros::Subscriber movement_status_sub = n.subscribe("/motion_controller/movement_status", 1, movement_callback2, ros::TransportHints().tcpNoDelay()); 
    timer = n.createTimer(ros::Duration(1.0/controlrate), timerCallback);
    timer.stop();
    timer_show = n.createTimer(ros::Duration(0.5), timercallback_show);
    timer_show.stop();
    pose_target_pub = n.advertise<planner::goal>("waypoints", 100);
    pose_target_show_pub = n.advertise<nav_msgs::Odometry>("/target_pose_show",10);
    monitor_pub = n.advertise<nav_msgs::Odometry>("/monitor",10);
    path_pub = n.advertise<nav_msgs::Path>("/path",10);
    ros::Subscriber odom_sub = n.subscribe("/ekf/ekf_odom", 1, odom_callback, ros::TransportHints().tcpNoDelay());   

    // must start at the beginning position
    trajectory_generator();
    border_show_init();

    //for simulator 
    sim_ref_pub = n.advertise<nav_msgs::Path>("path_ref", 1);
    sim_border_inner_pub = n.advertise<nav_msgs::Path>("path_border_inner", 1);
    sim_border_outer_pub = n.advertise<nav_msgs::Path>("path_border_outer", 1);
    Pathref.header.frame_id = "world";
    geometry_msgs::PoseStamped tmpPose;
    for(int i=0; i < Trajectory.size(); i++)
    {
        tmpPose.pose.position.x = Trajectory[i](0);
        tmpPose.pose.position.y = Trajectory[i](1);
        tmpPose.pose.position.z = 0;
        Quaterniond q(yaw2quaternion(Trajectory[i](3)));
        tmpPose.pose.orientation.w = q.w();
        tmpPose.pose.orientation.x = q.x();
        tmpPose.pose.orientation.y = q.y();
        tmpPose.pose.orientation.z = q.z();
        Pathref.poses.push_back(tmpPose);
    }

    //simulator
    sim_ref_pub.publish(Pathref);
    
    planner::goal nextpoint;
    size_t cnt = 0;
    nextpoint.x = Trajectory[cnt](0);
    nextpoint.y = Trajectory[cnt](1);
    nextpoint.theta = Trajectory[cnt](2);
    nextpoint.velocity = Trajectory[cnt](3);
    pose_target_pub.publish(nextpoint);
    ROS_INFO("Sent first point!");

    ros::spin();
}


void system_monitor_pub(ros::Time stamp, double x, double y, double z)
{
    nav_msgs::Odometry monitor;
    monitor.header.stamp = stamp;
    monitor.header.frame_id = "world";
    // monitor.header.frame_id = "imu";
    monitor.pose.pose.position.x = x;
    monitor.pose.pose.position.y = y;
    monitor.pose.pose.position.z = z;
    // Quaterniond q;
    // q = euler2quaternion(Z_measurement.segment<3>(3));
    // monitor.pose.pose.orientation.w = q.w();
    // monitor.pose.pose.orientation.x = q.x();
    // monitor.pose.pose.orientation.y = q.y();
    // monitor.pose.pose.orientation.z = q.z();
    // monitor.twist.twist.linear.x = Z_measurement(3);
    // monitor.twist.twist.linear.y = Z_measurement(4);
    // monitor.twist.twist.linear.z = Z_measurement(5);
    
    // monitor.twist.twist.angular.x = INNOVATION_(0);
    // monitor.twist.twist.angular.y = INNOVATION_(1);
    // monitor.twist.twist.angular.z = INNOVATION_(2);
    // Vector3d pp, qq, v, bg, ba;
    // getState(pp, qq, v, bg, ba);
    // monitor.twist.twist.angular.x = ba(0);
    // monitor.twist.twist.angular.y = ba(1);///??????why work??????????//////
    // monitor.twist.twist.angular.z = ba(2);
    // monitor.twist.twist.angular.x = diff_time;
    // monitor.twist.twist.angular.y = dt;
    monitor_pub.publish(monitor);
}