#include "ros/ros.h"
#include "planner/nextpose.h"
#include <cstdlib>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "add_two_ints_client");
  // if (argc != 3)
  // {
  //   ROS_INFO("usage: add_two_ints_client X Y");
  //   return 1;
  // }

  ros::NodeHandle n;
  ros::ServiceClient client = n.serviceClient<planner::nextpose>("mc");
  planner::nextpose srv;
  srv.request.a = 1;
  srv.request.b = 2;
  ros::Time t;
  t = ros::Time::now();
  // while (ros::ok())
  // {
  //   /* code */
  // }
  if (client.call(srv))  //spinning after call
  {
    ROS_INFO("Sum: ");
  }
  else
  {
    ROS_ERROR("Failed to call service add_two_ints");
    return 1;
  }
  ros::Duration tt = ros::Time::now() - t;

  std::cout << tt << std::endl;
 
  

  return 0;
}