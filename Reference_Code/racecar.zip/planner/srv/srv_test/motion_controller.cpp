#include "ros/ros.h"
#include "planner/nextpose.h"

bool add(planner::nextpose::Request  &req,
         planner::nextpose::Response &res)
{
  res.sum = req.a + req.b;
  ROS_INFO("request: x=%ld, y=%ld", (long int)req.a, (long int)req.b);
  ROS_INFO("sending back response: [%ld]", (long int)res.sum);
   while (ros::ok())
  {
    /* code */
  }
  return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "mc");
  ros::NodeHandle n;

  ros::ServiceServer service = n.advertiseService("mc", add);
  ROS_INFO("Ready to add two ints.");
 
  ros::spin();

  return 0;
}