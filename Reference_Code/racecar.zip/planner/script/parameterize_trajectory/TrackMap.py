import yaml
import numpy as np
from scipy import interpolate
from matplotlib import pyplot as plt
from matplotlib import animation

##
# class TrackMap:

#     traj = {}
#     theta = np.array([])

#     def __init__(self):
#         with open(r'OldTrack.yaml') as file:
#             data = yaml.load(file, Loader=yaml.FullLoader)
#         for traj in data:
#             data[traj] = data[traj] + [data[traj][0]]
#         size = len(data['xcenter'])
#         t = np.array([i for i in range(0, size)])
#         b_xcenter = interpolate.CubicSpline(t, data['xcenter'])
#         b_ycenter = interpolate.CubicSpline(t, data['ycenter'])
#         diff = np.sqrt(np.power(b_xcenter(t, 1), 2) + np.power(b_ycenter(t, 1), 2))
#         delta_theta = np.concatenate(([0], (diff[1:] + diff[0:-1]) / 2))
#         self.theta = np.cumsum(delta_theta)
#         for traj in data:
#             self.traj[traj] = interpolate.CubicSpline(self.theta, data[traj], bc_type='periodic')
#         plt.plot(data['xcenter'],data['ycenter'])
#         plt.show()
##

traj = {}
theta = np.array([])

with open(r'./planner/script/parameterize_trajectory/RoadPath.yaml') as file:
    data = yaml.load(file, Loader=yaml.FullLoader)
for traj in data:
    data[traj] = data[traj] + [data[traj][0]]
size = len(data['xcenter'])
t = np.array([i for i in range(0, size)])
scale = 3
datax = [x*scale for x in data['xcenter']]
datay = [x*scale for x in data['ycenter']]
b_xcenter = interpolate.CubicSpline(t, datax)
b_ycenter = interpolate.CubicSpline(t, datay)
diff = np.sqrt(np.power(b_xcenter(t, 1), 2) + np.power(b_ycenter(t, 1), 2))
delta_theta = np.concatenate(([0], (diff[1:] + diff[0:-1]) / 2))
theta = np.cumsum(delta_theta)
# for traj in data:
#     traj[traj] = interpolate.CubicSpline(theta, data[traj], bc_type='periodic')
plt.plot(datax,datay,'.')
plt.show()

