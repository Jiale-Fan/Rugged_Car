import yaml
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import animation
from scipy import interpolate

# R1 = 1.0
# R2 = 1.5
# R3 = 1.0
# L2 = 5.0
# L3 = 1.0
# car minimum steering radius: 1.5m 
# measure in the largest throttle and the largest steering angle and turning around（may not be the largest speed）
RR = 1.8 
R1 = RR
R2 = RR
R3 = RR
L2 = 2.5
L3 = 0
L1 = 8.0*R2 + 2.0*R3 +L3 - 2.0*R1

xcenter = np.linspace(0, L1/2, 40)
ycenter = np.array(40*[0])

theta_ = np.linspace(-np.math.pi/2, 0, 50)
a = L1/2
b = R1
R = R1
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

xcenter = np.append(xcenter, 40*[L1/2+R1])
ycenter = np.append(ycenter, np.linspace(R1, R1+L2, 40))

theta_ = np.linspace(0, np.math.pi, 100)
a = L1/2+R1-R2
b = R1+L2
R = R2
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

theta_ = np.linspace(0, -np.math.pi, 100)
a = L1/2+R1-3*R2
b = R1+L2
R = R2
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

xcenter = np.append(xcenter, 40*[L1/2+R1-4*R2])
ycenter = np.append(ycenter, np.linspace(R1+L2, R1+L2+L3, 40))

theta_ = np.linspace(0, np.math.pi/2, 50)
a = L1/2+R1-4*R2-R3
b = R1+L2+L3
R = R3
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

xcenter = np.append(xcenter, np.linspace(L1/2+R1-4*R2-R3, L1/2+R1-4*R2-R3-L3, 40))
ycenter = np.append(ycenter, 40*[R1+L2+L3+R3])

theta_ = np.linspace(np.math.pi/2, np.math.pi, 50)
a = L1/2+R1-4*R2-R3-L3
b = R1+L2+L3
R = R3
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

xcenter = np.append(xcenter, 40*[L1/2+R1-4*R2-L3-2*R3])
ycenter = np.append(ycenter, np.linspace(R1+L2+L3, R1+L2, 40))

theta_ = np.linspace(0, -np.math.pi, 100)
a = L1/2+R1-5*R2-2*R3-L3
b = R1+L2
R = R2
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

theta_ = np.linspace(0, np.math.pi, 100)
a = L1/2+R1-7*R2-2*R3-L3
b = R1+L2
R = R2
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

xcenter = np.append(xcenter, 40*[L1/2+R1-8*R2-2*R3-L3])
ycenter = np.append(ycenter, np.linspace(R1+L2, R1, 40))

theta_ = np.linspace(-np.math.pi, -np.math.pi/2, 50)
a = L1/2+R1-8*R2-2*R3+R1-L3
b = R1
R = R1
xcenter = np.append(xcenter, R*np.cos(theta_)+a)
ycenter = np.append(ycenter, R*np.sin(theta_)+b)

xcenter = np.append(xcenter, np.linspace(L1/2+R1-8*R2-2*R3+R1-L3, 0, 40))
ycenter = np.append(ycenter, np.array(40*[0]))

map_legth = L1 + 2*L2 + 3*L3 + np.math.pi*R1 + 4*np.math.pi*R2 + np.math.pi*R3
print("path length: ", map_legth)

dic = {}
dic['xcenter'] = xcenter.tolist()
dic['ycenter'] = ycenter.tolist()

# # circle
# theta_ = np.linspace(-np.math.pi/2, np.math.pi, 150)
# theta_ = np.append(theta_, np.linspace(-np.math.pi, -np.math.pi/2, 50))
# a = 0
# b = R1
# R = R1
# xcenter = R*np.cos(theta_)+a
# ycenter = R*np.sin(theta_)+b
# dic = {}
# dic['xcenter'] = xcenter.tolist()
# dic['ycenter'] = ycenter.tolist()

with open(r'./RoadPath.yaml', 'w') as f:  #RoadPath.yaml is raw path for the path shape and will be used in global_racetrajectory_optimization to generate a border and a minimum curvature track(saved in RacecarTrack.yaml)
    yaml.dump(dic, f)

# In[]
plt.plot(xcenter,ycenter,'.')
plt.show()


plt.waitforbuttonpress()


