ackermann_msgs
==============

ROS messages for vehicles using front-wheel `Ackermann steering`_. It
was defined by the ROS `Ackermann steering group`_.

ROS documentation: http://www.ros.org/wiki/ackermann_msgs

.. _Ackermann steering: http://en.wikipedia.org/wiki/Ackermann_steering_geometry
.. _Ackermann steering group: http://www.ros.org/wiki/Ackermann%20Group
